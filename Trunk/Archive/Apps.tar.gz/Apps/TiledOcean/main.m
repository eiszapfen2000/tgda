#import <AppKit/AppKit.h>
#import "TODocumentController.h"
#import "Core/NPEngineCore.h"

int main(int argc, const char *argv[])
{
    return  NSApplicationMain(argc, argv);
}


