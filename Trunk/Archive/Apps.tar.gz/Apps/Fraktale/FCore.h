#import "FApplicationController.h"
#import "FWindowController.h"

@class NP;

@interface NP ( Fraktale )

+ (FApplicationController *) applicationController;
+ (FWindowController *) attributesWindowController;

@end
