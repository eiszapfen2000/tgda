#import "ODApplicationController.h"

@class NP;

@interface NP ( OceanDemo )

+ (ODApplicationController *) applicationController;

@end
