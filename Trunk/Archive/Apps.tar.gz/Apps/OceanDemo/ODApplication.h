#import <AppKit/AppKit.h>

@interface ODApplication : NSApplication
@end
