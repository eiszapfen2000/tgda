#import <AppKit/AppKit.h>

@class ODScene;

@interface ODWindowController : NSObject

- (void) windowWillClose:(NSNotification *)aNotification;

@end
