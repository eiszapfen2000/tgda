#import "RTVApplicationController.h"

@class NP;

@interface NP ( RTV )

+ (RTVApplicationController *) applicationController;

@end


