#import "NP.h"

int main(int argc, const char *argv[])
{
    return  NPApplicationMain(argc, argv);
}
