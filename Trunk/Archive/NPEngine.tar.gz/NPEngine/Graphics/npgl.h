#ifndef _NP_GL_H_
#define _NP_GL_H_

#include "GL/glew.h"
#include "GL/glxew.h"

#include "Cg/cg.h"
#include "Cg/cgGL.h"

#endif
