#import "NPPathManager.h"
#import "NPLocalPathManager.h"
#import "NPRemotePathManager.h"
#import "NPPathUtilities.h"
#import "NP.h"

@implementation NPPathManager

- (id) init
{
    return [ self initWithName:@"NPEngine Pathmanager" ];
}

- (id) initWithName:(NSString *)newName
{
    return [ self initWithName:newName parent:nil ];
}

- (id) initWithName:(NSString *)newName parent:(id <NPPObject> )newParent
{
    self = [ super initWithName:newName parent:newParent ];

    fileManager = [ NSFileManager defaultManager ];

    localPathManager  = [[ NPLocalPathManager alloc  ] initWithName:@"NPEngine Local Path Manager"  parent:self ];
    remotePathManager = [[ NPRemotePathManager alloc ] initWithName:@"NPEngine Remote Path Manager" parent:self ];

    return self;
}

- (void) dealloc
{
    [ localPathManager release ];
    [ remotePathManager release ];

    [ super dealloc ];
}

- (void) addLookUpPath:(NSString *)lookUpPath
{
    NSString * standardizedLookUpPath = [ lookUpPath stringByStandardizingPath ];
    //NPLOG(@"%@ expand to %@", lookUpPath, standardizedLookUpPath);

    if ( [[ NSFileManager defaultManager ] isDirectory:standardizedLookUpPath ] == YES )
    {
        [ localPathManager addLookUpPath:standardizedLookUpPath ];
    }
    else if ( [[ NSFileManager defaultManager ] isURL:lookUpPath ] == YES )
    {
        [ remotePathManager addLookUpURL:[ NSURL URLWithString:lookUpPath ] ];
        NPLOG(@"%@ added to lookup URLs", lookUpPath);
    }
    else
    {
        NPLOG(@"%@: %@ is not a valid directory or URL", name, lookUpPath);
    }
}

- (void) removeLookUpPath:(NSString *)lookUpPath
{
    NSString * standardizedLookUpPath = [ lookUpPath stringByStandardizingPath ];

    if ( [[ NSFileManager defaultManager ] isDirectory:standardizedLookUpPath ] == YES )
    {
        [ localPathManager removeLookUpPath:standardizedLookUpPath ];
    }
    else if ( [[ NSFileManager defaultManager ] isURL:lookUpPath ] == YES )
    {
        [ remotePathManager removeLookUpURL:[ NSURL URLWithString:lookUpPath ] ];
    }
}

- (NSString *) getAbsoluteFilePath:(NSString *)partialPath;
{
    return [ localPathManager getAbsoluteFilePath:partialPath ];
}

@end
