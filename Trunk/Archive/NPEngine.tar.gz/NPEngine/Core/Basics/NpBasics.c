#include "NpBasics.h"

void npbasics_initialise()
{
    crc32_initialise();
}
