#ifndef _NP_BASICS_HALF_H_
#define _NP_BASICS_HALF_H_

#include "NpTypes.h"

Float half_to_float(Half h);

#endif
