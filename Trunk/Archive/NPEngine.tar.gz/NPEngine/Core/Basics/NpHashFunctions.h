#ifndef _NP_HASH_FUNCTIONS_H_
#define _NP_HASH_FUNCTIONS_H_

#include "NpTypes.h"

UInt32 SuperFastHash (const char * data, UInt32 length);

#endif //_NP_HASH_FUNCTIONS_H_
