#ifndef _NP_BASICS_BASICS_H_
#define _NP_BASICS_BASICS_H_

#include "NpTypes.h"
#include "NpCrc32.h"
#include "NpHalf.h"
#include "NpHashFunctions.h"
#include "NpMemory.h"
#include "NpFreeList.h"

void npbasics_initialise();

#endif
